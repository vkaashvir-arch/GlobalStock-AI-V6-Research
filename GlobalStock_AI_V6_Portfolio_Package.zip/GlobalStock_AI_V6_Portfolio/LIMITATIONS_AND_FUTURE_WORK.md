
# Limitations and Future Work

## Current Research Limitations

1. Model performance varies across assets and horizons.
2. Average accuracy is close to the baseline.
3. ROC-AUC results do not establish a strong general
   classification advantage.
4. Historical holdout performance does not guarantee
   future performance.
5. Market regime changes may affect model behaviour.
6. Real-world trading costs and execution were not evaluated.
7. Only a limited selection of model families was tested.

## Future Research Directions

- Improve data-quality diagnostics.
- Investigate additional chronological validation periods.
- Study model calibration and prediction uncertainty.
- Examine feature importance and interpretability.
- Test robustness across different historical periods.
- Evaluate additional carefully selected model families.
- Improve experiment tracking and reproducibility.
- Preserve earlier project versions.

## Responsible Use

This project is intended for educational and research
purposes only.

It is not a financial recommendation or a validated
real-money decision system.
