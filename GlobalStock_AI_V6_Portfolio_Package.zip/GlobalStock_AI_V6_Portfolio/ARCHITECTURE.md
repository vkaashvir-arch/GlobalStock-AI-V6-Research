
# GlobalStock AI V6 — Architecture

## Research Pipeline

Historical Data Collection
        |
        v
Data Quality Audit
        |
        v
Feature Engineering
        |
        v
Dataset Cleaning
        |
        v
Chronological Train/Test Split
        |
        v
Majority-Class Baseline
        |
        v
Machine-Learning Training
        |
        +----------------------+
        |                      |
        v                      v
Logistic Regression      Random Forest
        |                      |
        +----------+-----------+
                   |
                   v
            Model Evaluation
                   |
                   v
          Baseline Comparison
                   |
                   v
         Research Visualizations
                   |
                   v
            Final PDF Report

## Main Components

- data/: Historical datasets.
- features/: Engineered features.
- cleaned_data/: Cleaned datasets.
- train_test_split/: Training and testing data.
- models/: Saved model artifacts.
- results/: Experiment results and summaries.
- reports/: Audits, charts and research reports.
- portfolio_package/: Final documentation.
