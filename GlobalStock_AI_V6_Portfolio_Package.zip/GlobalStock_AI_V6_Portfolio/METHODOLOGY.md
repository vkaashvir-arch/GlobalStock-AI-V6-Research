
# GlobalStock AI V6 — Methodology

## 1. Dataset

Approximately five years of historical daily data were
collected for 33 assets.

One originally planned asset was excluded because
sufficient historical data was unavailable.

## 2. Data Quality

Downloaded datasets were checked for:

- Missing values
- Duplicate dates
- Invalid prices
- Invalid OHLC relationships
- Negative volume
- Chronological ordering

## 3. Feature Engineering

Features included:

- Daily, 5-day and 10-day returns
- Simple moving averages
- Exponential moving averages
- RSI
- MACD
- Bollinger Bands
- Rolling volatility
- Average True Range
- Volume ratio

Target columns were excluded from model predictors.

Date and ticker identifiers were also excluded.

## 4. Dataset Cleaning

Rows with missing predictor values or missing target labels
were removed independently for each asset and horizon.

Infinite values were treated as invalid observations.

## 5. Chronological Split

Each dataset used:

- 80% earlier observations for training
- 20% later observations for testing

Boundary observations were purged to prevent overlapping
future target periods.

## 6. Baseline Model

A majority-class DummyClassifier was trained using
training labels only.

Its predictions were evaluated on the test dataset.

## 7. Machine-Learning Models

### Logistic Regression

A StandardScaler and LogisticRegression pipeline
was used with class weighting enabled.

### Random Forest

The model used:

- 300 trees
- Maximum depth of 8
- Minimum leaf size of 5
- Balanced subsample class weights

## 8. Evaluation Metrics

- Accuracy
- Balanced accuracy
- Precision
- Recall
- F1-score
- ROC-AUC

## 9. Experiments

The project evaluated 132 experiments
across 33 assets.

Two prediction horizons and two model types were tested.

## 10. Interpretation

The results are historical experimental measurements.

They do not establish reliable future forecasting ability.
