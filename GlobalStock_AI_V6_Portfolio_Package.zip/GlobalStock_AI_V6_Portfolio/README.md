
# GlobalStock AI V6

An educational machine-learning research project exploring
historical financial time-series data.

The project evaluates classification models against a
majority-class baseline using chronological testing.

## Project Overview

- Historical assets evaluated: 33
- Machine-learning experiments: 132
- Prediction horizons: 1-day and 5-day
- Models: Logistic Regression and Random Forest
- Data split: Chronological 80/20
- Baseline: Majority-class classifier

## Research Results

| Horizon | Model | Accuracy | Baseline | Balanced Accuracy | ROC-AUC | Improvement | Beat Baseline |
|---|---|---:|---:|---:|---:|---:|---:|
| 1D | LogisticRegression | 49.87% | 50.01% | 50.17% | 50.58% | -0.14 pp | 16/33 |
| 1D | RandomForest | 49.71% | 50.01% | 50.49% | 51.23% | -0.30 pp | 17/33 |
| 5D | LogisticRegression | 47.75% | 48.88% | 48.71% | 49.46% | -1.13 pp | 14/33 |
| 5D | RandomForest | 49.66% | 48.88% | 51.33% | 52.15% | +0.78 pp | 18/33 |

Accuracy improvement is measured in percentage points (pp).

Results represent averages across asset-level experiments,
not pooled market-wide performance.

## Methodology

1. Historical data collection.
2. Data quality auditing.
3. Feature engineering.
4. Dataset cleaning.
5. Chronological train/test splitting.
6. Majority-class baseline evaluation.
7. Logistic Regression training.
8. Random Forest training.
9. Model evaluation.
10. Baseline comparison.
11. Research visualization.
12. Final report generation.

## Project Structure

GlobalStock_AI_V6/

    data/
    features/
    cleaned_data/
    train_test_split/
    models/
    results/
    reports/
    portfolio_package/

## Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn
- yfinance
- Google Colab

## Research Report

See research_report.pdf for the detailed research report
and visualizations.

## Limitations

- Historical patterns may not persist.
- Model accuracy is close to the baseline.
- Performance varies across assets and horizons.
- Historical holdout results do not guarantee future performance.
- Real-world transaction costs and execution are not evaluated.

## Responsible Use

This is an experimental educational research project.

It is not a financial recommendation or a validated
real-money decision system.

## Project Status

V6 research experiments and documentation package generated.

Generated on: 2026-11-24
